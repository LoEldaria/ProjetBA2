#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

#include "Ciel.h"
// #include "ChampPotentiels.h"
// #include "Constantes.h"


using namespace std;

int main() {

    //initialisation des valeurs au loin dans la plaine
    Physique::Parametres simulation (20,284.5,101325);
    
    array<unsigned int,3>centre={15,15,15};
    Montagne K2 (centre, 5, 5); 

    ChampPotentiels cp (&simulation, 30,30,30,20.0/29.0);
    Ciel sky (cp, &simulation);
    
    
    cp.initialise(K2);
    cp.resolution(pow(20.0/29.0, 4)*1e-4);

    ofstream fichier("re2.txt");
    //pour pouvoir visualiser toutes les valeurs sans être limité par le terminal
    
    sky.update(cp);
    sky.affiche_val(fichier);
    //affichage: i j k V2 h T P Peau Prosee nuage

    fichier.close();
    return 0;
}