//
// Created by siddharth on 09/04/2021.
//
#include <fstream>
#include "Systeme.h"
#include "TextViewer.h"
#include "MontGaussienne.h"
#include "ChaineDeMontagnes.h"
using namespace std;


/*
 //Pour le TestMontagne2 (ajout de plusieurs montagnes, sortie sur cout):

int main(){

   MontGaussienne mont({2,22,12},12,3);
   MontGaussienne mont2({20,2,15},8,4);
   ChaineDeMontagnes chaine;
   chaine.ajoute_montagne(mont);
   chaine.ajoute_montagne(mont2);
   MontGaussienne mont3({15,15,18},5,10);

   ChaineDeMontagnes Chaine;
   Chaine.ajoute_montagne(chaine);
   Chaine.ajoute_montagne(mont3);
   Chaine.affiche_altitude(cout, 30, 30);
  return 0;
}
*/

int main()
{
    ofstream fichier("re_5.txt");
    /* Nous voulons un support à dessin :                          *
     * ici un TextViewer qui écrit sur cout                        */
    TextViewer ecran(fichier);

    MontGaussienne everest({15,15,15},5,5);

    // Nous voulons un contenu à dessiner
    Systeme c(20,284.5,101325, 30,30,30,20.0/29.0);
    c.ajoute_montagne(everest);

    c.demarre();
    c.evolue(0.031);
    c.evolue(.031);
    c.evolue(.031);
    c.dessine_sur(ecran);

    //autre syntaxe possible
//    double dt(0.05);
//    for(int i(0);i<5;++i){
//        c.evolue(dt);
//        c.dessine_sur(ecran);
//    }


    
    fichier.close();
    return 0;
}
