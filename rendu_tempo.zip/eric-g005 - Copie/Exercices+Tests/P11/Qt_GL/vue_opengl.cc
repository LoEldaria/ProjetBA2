#include "vue_opengl.h"
#include "vertex_shader.h" // Identifiants Qt de nos différents attributs
#include "Systeme.h"



void VueOpenGL::dessine(Systeme const& a_dessiner){

    glClearColor(1, 1, 1, 1); //fond blanc
    /*quand on appelle cette méthode avec dessine_sur() dans demarre() de systeme,
    on a normalement que la résolution de laplace et donc l'updste du ciel sont déjà fait */
    QMatrix4x4 matrice;

    dessineAxes(matrice,true);// dessine le repère principal
    dessineBoite(matrice, a_dessiner);
    dessine(a_dessiner.get_ciel());
}

void VueOpenGL::dessine(const Montagne &a_dessiner)
{

}

void VueOpenGL::dessine(Ciel const& a_dessiner){
    a_dessiner.applique_fonction([&](const CubedAir& cba, std::size_t i, std::size_t j, std::size_t k){
        if(cba.nuage()) dessineSphere(a_dessiner.coordonnees(i,j,k), (2./3)*(a_dessiner.get_lambda()),false);
    });
}




// ======================================================================
void VueOpenGL::init(Vecteur3D sommet_boite)
{
  /* Initialise notre vue OpenGL.
   * Dans cet exemple, nous créons et activons notre shader.
   *
   * En raison du contenu des fichiers *.glsl, le shader de cet exemple
   * NE permet QUE de dessiner des primitives colorées
   * (pas de textures, brouillard, reflets de la lumière ou autres).
   *
   * Il est séparé en deux parties VERTEX et FRAGMENT.
   * Le VERTEX :
   * - récupère pour chaque sommet des primitives de couleur (dans
   *     l'attribut couleur) et de position (dans l'attribut sommet)
   * - multiplie l'attribut sommet par les matrices 'vue_modele' et
   *     'projection' et donne le résultat à OpenGL
   *   - passe la couleur au shader FRAGMENT.
   *
   * Le FRAGMENT :
   *   - applique la couleur qu'on lui donne
   */

  prog.addShaderFromSourceFile(QOpenGLShader::Vertex,   ":/vertex_shader.glsl");
  prog.addShaderFromSourceFile(QOpenGLShader::Fragment, ":/fragment_shader.glsl");

  /* Identifie les deux attributs du shader de cet exemple
   * (voir vertex_shader.glsl).
   *
   * L'attribut identifié par 0 est particulier, il permet d'envoyer un
   * nouveau "point" à OpenGL
   *
   * C'est pourquoi il devra obligatoirement être spécifié et en dernier
   * (après la couleur dans cet exemple, voir plus bas).
   */

  prog.bindAttributeLocation("sommet",  SommetId);
  prog.bindAttributeLocation("couleur", CouleurId);

  // Activation du shader
  prog.bind();

  /* Activation du "Test de profondeur" et du "Back-face culling"
   * Le Test de profondeur permet de dessiner un objet à l'arrière-plan
   * partielement caché par d'autres objets.
   *
   * Le Back-face culling consiste à ne dessiner que les face avec ordre
   * de déclaration dans le sens trigonométrique.
   */
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  sphere.initialize();
  initializePosition(sommet_boite);
}

// ======================================================================
void VueOpenGL::initializePosition(Vecteur3D sb)
{
  // position initiale
  matrice_vue.setToIdentity();
  translate(-sb[0],-sb[1],-sb[2]);
  rotate(-30.0, 0.0, 0.0, 1.0);
  rotate(-70.0, 1.0, 0.0, 0.0);
  translate(0,sb.norme()/4,-sb.norme()/2); //point de vue adapté à la taille de la boite
}

// ======================================================================
void VueOpenGL::translate(double x, double y, double z)
{
  /* Multiplie la matrice de vue par LA GAUCHE.
   * Cela fait en sorte que la dernière modification apportée
   * à la matrice soit appliquée en dernier (composition de fonctions).
   */
  QMatrix4x4 translation_supplementaire;
  translation_supplementaire.translate(x, y, z);
  matrice_vue = translation_supplementaire * matrice_vue;
}

// ======================================================================
void VueOpenGL::rotate(double angle, double dir_x, double dir_y, double dir_z)
{
  // Multiplie la matrice de vue par LA GAUCHE
  QMatrix4x4 rotation_supplementaire;
  rotation_supplementaire.rotate(angle, dir_x, dir_y, dir_z);
  matrice_vue = rotation_supplementaire * matrice_vue;
}

void VueOpenGL::translate(QMatrix4x4 & matrice, const Vecteur3D & v)
{
    matrice.translate(v[0],v[1],v[2]);
}




//=======================================================================

void VueOpenGL::dessineAxes (QMatrix4x4 const& point_de_vue, bool en_couleur)
{
  prog.setUniformValue("vue_modele", matrice_vue * point_de_vue);
  //matrice_vue=matrice de point de vue, qui a en mémoire le point de vue courant

  glBegin(GL_LINES);

  // axe X
  if (en_couleur) {
    prog.setAttributeValue(CouleurId, 1.0, 0.0, 0.0); // rouge
  } else {
    prog.setAttributeValue(CouleurId, 1.0, 1.0, 1.0); // blanc
  }
  prog.setAttributeValue(SommetId, 0.0, 0.0, 0.0);
  prog.setAttributeValue(SommetId, 10.0, 0.0, 0.0); //on veut des axes assez grands

  // axe Y
  if (en_couleur) prog.setAttributeValue(CouleurId, 0.0, 1.0, 0.0); // vert
  prog.setAttributeValue(SommetId, 0.0, 0.0, 0.0);
  prog.setAttributeValue(SommetId, 0.0, 10.0, 0.0);

  // axe Z
  if (en_couleur) prog.setAttributeValue(CouleurId, 0.0, 0.0, 1.0); // bleu
  prog.setAttributeValue(SommetId, 0.0, 0.0, 0.0);
  prog.setAttributeValue(SommetId, 0.0, 0.0, 10.0);

  glEnd();
}

void VueOpenGL::dessineBoite(QMatrix4x4 const& point_de_vue, Systeme const& syst){

    dessineSegment(point_de_vue, syst.get_coord(0,0,0), syst.get_coord(-1,0,0));
    dessineSegment(point_de_vue, syst.get_coord(0,0,0), syst.get_coord(0,-1,0));
    dessineSegment(point_de_vue, syst.get_coord(0,0,0), syst.get_coord(0,0,-1));
    dessineSegment(point_de_vue, syst.get_coord(0,-1,-1), syst.get_coord(-1,-1,-1));
    dessineSegment(point_de_vue, syst.get_coord(0,-1,-1), syst.get_coord(0,0,-1));
    dessineSegment(point_de_vue, syst.get_coord(0,-1,-1), syst.get_coord(0,-1,0));
    dessineSegment(point_de_vue, syst.get_coord(-1,-1,0), syst.get_coord(0,-1,0));
    dessineSegment(point_de_vue, syst.get_coord(-1,-1,0), syst.get_coord(-1,0,0));
    dessineSegment(point_de_vue, syst.get_coord(-1,-1,0), syst.get_coord(-1,-1,-1));
    dessineSegment(point_de_vue, syst.get_coord(-1,0,-1), syst.get_coord(0,0,-1));
    dessineSegment(point_de_vue, syst.get_coord(-1,0,-1), syst.get_coord(-1,-1,-1));
    dessineSegment(point_de_vue, syst.get_coord(-1,0,-1), syst.get_coord(-1,0,0));

}


void VueOpenGL::dessineSegment (QMatrix4x4 const& point_de_vue, Vecteur3D v1,Vecteur3D v2, Vecteur3D color)
{


  prog.setUniformValue("vue_modele", matrice_vue * point_de_vue);
  glBegin(GL_LINES);
  prog.setAttributeValue(CouleurId, color[0],color[1],color[2]); // gris
  prog.setAttributeValue(SommetId,v1[0] ,v1[1] ,v1[2]);
  prog.setAttributeValue(SommetId,v2[0] ,v2[1] ,v2[2]);
  glEnd();

}

void VueOpenGL::dessineSphere(Vecteur3D centre, double rayon, bool pleine, Vecteur3D color){

  QMatrix4x4 matrice;
  translate(matrice, centre);
  matrice.scale(rayon);

  if(!pleine) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
  prog.setUniformValue("vue_modele", matrice_vue * matrice);
  prog.setAttributeValue(CouleurId, color[0], color[1], color[2]);  // met la couleur
  sphere.draw(prog, SommetId);                                      // dessine la sphère

  if(!pleine) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); //on repasse par défaut en fill
}




// ======================================================================
/*void VueOpenGL::dessine(Contenu const& a_dessiner)
{
   // Dessine le 1er cube (à l'origine)
  dessineCube();

  QMatrix4x4 matrice;
  // Dessine le 2e cube
  matrice.translate(0.0, 1.5, 0.0); // à chaque étape on mémorise le point de vue dans matrice_vue
  matrice.scale(0.25);
  dessineCube(matrice);

  // Dessine le 3e cube
  matrice.setToIdentity();
  matrice.translate(0.0, 0.0, 1.5);
  matrice.scale(0.25);
  matrice.rotate(45.0, 0.0, 1.0, 0.0);
  dessineCube(matrice);

  // Dessine le 4e cube
  matrice.setToIdentity();
  matrice.rotate(a_dessiner.infos(), 1.0, 0.0, 0.0); //rotation se fait après translation
  matrice.translate(0.0, 2.3, 0.0);
  matrice.scale(0.2);
  dessineCube(matrice);
}*/


// ======================================================================
/*void VueOpenGL::dessineCube (QMatrix4x4 const& point_de_vue)
{
  prog.setUniformValue("vue_modele", matrice_vue * point_de_vue);

  glBegin(GL_QUADS);
  // face coté X = +1
  prog.setAttributeValue(CouleurId, 1.0, 0.0, 0.0); // rouge
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);

  // face coté X = -1
  prog.setAttributeValue(CouleurId, 0.0, 1.0, 0.0); // vert
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);

  // face coté Y = +1
  prog.setAttributeValue(CouleurId, 0.0, 0.0, 1.0); // bleu
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);

  // face coté Y = -1
  prog.setAttributeValue(CouleurId, 0.0, 1.0, 1.0); // cyan
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);

  // face coté Z = +1
  prog.setAttributeValue(CouleurId, 1.0, 1.0, 0.0); // jaune
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);

  // face coté Z = -1
  prog.setAttributeValue(CouleurId, 1.0, 0.0, 1.0); // magenta
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);

  glEnd();
}*/
