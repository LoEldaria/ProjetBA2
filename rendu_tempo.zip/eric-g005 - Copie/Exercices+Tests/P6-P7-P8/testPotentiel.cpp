#include <iostream>
#include "ChampPotentiels.h"

using namespace std;

int main() {
Physique::Parametres simulation (20,284.5,101325);

ChampPotentiels cp (&simulation, 30,30,30,20.0/29.0);
array<unsigned int,3>centre={15,15,15};
Montagne K2 (centre, 5, 5); 

cp.initialise(K2); // le premier argument est la vitesse du vent aux limites de la boite

cp.affiche(cout, potentiel, laplacien);

return 0;
}